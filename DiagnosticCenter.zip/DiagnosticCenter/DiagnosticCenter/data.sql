insert into center (CENTERID,ADDRESS,CENTERNAME,CONTACTNO) values ('21111','gujaini','asd',12345674);

insert into center (CENTERID,ADDRESS,CENTERNAME,CONTACTNO) values ('20000','barra','polio',12345674);

commit;