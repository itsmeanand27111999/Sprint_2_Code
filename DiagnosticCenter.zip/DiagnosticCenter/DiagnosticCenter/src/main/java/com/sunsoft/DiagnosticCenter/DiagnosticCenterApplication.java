package com.sunsoft.DiagnosticCenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiagnosticCenterApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiagnosticCenterApplication.class, args);
	}

}
