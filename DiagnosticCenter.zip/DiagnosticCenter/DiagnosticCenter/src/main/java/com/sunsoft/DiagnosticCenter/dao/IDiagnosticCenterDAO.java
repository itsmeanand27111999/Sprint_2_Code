package com.sunsoft.DiagnosticCenter.dao;
import java.util.List;

import com.sunsoft.DiagnosticCenter.entity.*;
public interface IDiagnosticCenterDAO {
	List<DiagnosticCenter> getAllCenters();

	List<DiagnosticCenter> getCenter(String id);

	int deleteCenter(String id);

	DiagnosticCenter addCenter(DiagnosticCenter center);

}
