package com.sunsoft.DiagnosticCenter.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sunsoft.DiagnosticCenter.entity.DiagnosticCenter;
import com.sunsoft.DiagnosticCenter.repository.CenterRepository;

@Component
public class DiagnosticCenterDAO implements IDiagnosticCenterDAO{
	

		@Autowired
	    private CenterRepository repository;

		@Override
		public List<DiagnosticCenter> getAllCenters() {
			return repository.findAll();
		}
		@Override
		public List<DiagnosticCenter> getCenter(String id){
			return repository.getCenterById(id);		
		}
		@Override
		public int deleteCenter(String id){
			
		return	repository.deleteCenterById(id);	
			
		}
		@Override
		public DiagnosticCenter addCenter(DiagnosticCenter center) {
			return repository.save(center);
		}
	}


