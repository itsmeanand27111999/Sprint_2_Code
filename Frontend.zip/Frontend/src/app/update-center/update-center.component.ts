import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-center',
  templateUrl: './update-center.component.html',
  styleUrls: ['./update-center.component.css']
})
export class UpdateCenterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
