import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { AddCenterComponent } from './add-center/add-center.component';
import { UpdateCenterComponent } from './update-center/update-center.component';
import { CenterService } from './center.service';
import { HttpClientModule} from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { DiagnosticCenterComponent } from './diagnostic-center/diagnostic-center.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { FooterComponent } from './footer/footer.component';
import { AdminComponent } from './admin/admin.component';
import {Ng2TelInputModule} from 'ng2-tel-input';



@NgModule({
  declarations: [
    AppComponent,
    
    AddCenterComponent,
    UpdateCenterComponent,
    DiagnosticCenterComponent,
   
    HeaderComponent,
    HomeComponent,
    AboutComponent,
    FooterComponent,
    AdminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    
  ],
  providers: [CenterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
