

export class DiagnosticCenter{
    centerId: string;
    centerName: string;
    contactNo: BigInteger;
    address: string;
}
