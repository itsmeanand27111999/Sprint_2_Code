import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { DiagnosticCenter } from '../model/diagnosticcenter.model';
@Injectable({
  providedIn: 'root'
})
export class DiagnosticCenterService {
  router: any;
  constructor(private http:HttpClient){}
  private diagnosticcenterUrl = 'http://localhost:8887/show_centers';
  private deletecenterUrl = "http://localhost:8887/delete_center_by_id";
  private addcenterUrl = "http://localhost:8887/add_center";

  public getCenter(): Observable<DiagnosticCenter[]>
    {
      
      return this.http.get<DiagnosticCenter[]>(this.diagnosticcenterUrl);
    }


 
  public deletecenter(DiagnosticCenter): Observable<DiagnosticCenter[]>
    {
      alert('Center Deleted Successfully');
      return this.http.get<any>(this.deletecenterUrl + '/' + DiagnosticCenter);

    }
    public addCenter(center) {

     
      return this.http.post<DiagnosticCenter>(this.addcenterUrl, center);
    }
    
}
