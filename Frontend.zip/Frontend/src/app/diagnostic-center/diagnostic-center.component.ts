import { Component, OnInit } from '@angular/core';


import {Router} from '@angular/router';
import { DiagnosticCenterService } from './diagnostic-center.service';
import { DiagnosticCenter } from '../model/diagnosticcenter.model';
@Component({
  selector: 'app-diagnostic-center',
  templateUrl: './diagnostic-center.component.html',
  styleUrls: ['./diagnostic-center.component.css']
})
export class DiagnosticCenterComponent implements OnInit {
  centerId:String;
  centerName:String;
  contactNo:BigInteger;
  address:String;
  diagnosticcenter: DiagnosticCenter[];
  message:any;
  constructor(private router:Router, private diagnosticcenterService: DiagnosticCenterService) { }

  ngOnInit() {
   
    this.diagnosticcenterService.getCenter().subscribe(data => {this.diagnosticcenter = data;})
    console.log(this.diagnosticcenter);
    
  };
  deletecenter(center){
    
    this.diagnosticcenterService.deletecenter(center)
    .subscribe(data=>{

    this.router.navigate(['/diagnostic-center']);
    });

  };
  
}
//hum ja re isko bad me dekhenge