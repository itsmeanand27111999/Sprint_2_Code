import { Component, OnInit } from '@angular/core';
import { DiagnosticCenter } from '../model/diagnosticcenter.model';
import { DiagnosticCenterService } from './diagnostic-center.service';
import{Router} from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-add-center',
  templateUrl: './add-center.component.html',
  styleUrls: ['./add-center.component.css']
})
export class AddCenterComponent implements OnInit {
  diagnosticcenter: DiagnosticCenter[];
  message:any;
  dgcenter:DiagnosticCenter = new  DiagnosticCenter();

  constructor(private router: Router, private diagnosticcenterservice: DiagnosticCenterService,private http:HttpClient) { }

  ngOnInit(){
    this.diagnosticcenterservice.getCenter().subscribe(data=>{this.diagnosticcenter = data;});
  };
  
  addcenter(){
    this.diagnosticcenterservice.addCenter(this.dgcenter)
    .subscribe( data => {
      this.router.navigate(['/diagnostic-center']);
    });
  }
}
