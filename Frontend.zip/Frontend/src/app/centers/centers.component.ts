import { Component, OnInit } from '@angular/core';
import {Centers} from '../model/center.model';
@Component({
  selector: 'app-centers',
  templateUrl: './centers.component.html',
  styleUrls: ['./centers.component.css']
})
export class CentersComponent implements OnInit {
  centers : Centers[];
    constructor() { }

  ngOnInit(): void {
  }

}
