import { TestBed } from '@angular/core/testing';

import { DiagnosticCenterServiceService } from './diagnostic-center-service.service';

describe('DiagnosticCenterServiceService', () => {
  let service: DiagnosticCenterServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DiagnosticCenterServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
