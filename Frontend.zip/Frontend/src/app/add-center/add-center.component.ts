import { Component, OnInit } from '@angular/core';


import{Router} from '@angular/router';
import { DiagnosticCenterService } from '../diagnostic-center/diagnostic-center.service';
import { DiagnosticCenter } from '../model/diagnosticcenter.model';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-add-center',
  templateUrl: './add-center.component.html',
  styleUrls: ['./add-center.component.css']
})
export class AddCenterComponent implements OnInit {
  //[x: string]: any;
  //center: DiagnosticCenter[];
  
  center: DiagnosticCenter = new DiagnosticCenter();
  message:any;
  constructor(private router: Router, private diagnosticcenterservice: DiagnosticCenterService, private http:HttpClient) { }

  ngOnInit(){
  };

  public addcenter(){
    alert(this.center.centerId+this.center.centerName+this.center.contactNo+this.center.address);
    this.diagnosticcenterservice.addCenter(this.center)
    .subscribe( data => {
     /* this.router.navigate(['/diagnostic-center']);*/
     alert("Center created successfully!!");
    }); 

  }
  
}
