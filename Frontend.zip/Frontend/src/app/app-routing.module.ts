import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import  { AddCenterComponent } from './add-center/add-center.component';
import  { DiagnosticCenterComponent } from './diagnostic-center/diagnostic-center.component';
import { AboutComponent } from './about/about.component';
import { AdminComponent } from './admin/admin.component';
import {HomeComponent} from './home/home.component';

const routes: Routes = [
  {path: 'centers', pathMatch: 'full', component:DiagnosticCenterComponent},
  {path: 'add', component:AddCenterComponent},
  {path: 'about', component : AboutComponent},
  {path:'admin',component:AdminComponent},
  {path:'home',component:HomeComponent},
 {path:'diagnostic-center',component:DiagnosticCenterComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
 