import { TestBed } from '@angular/core/testing';

import { DiagnosticcenterserviceService } from './diagnosticcenterservice.service';

describe('DiagnosticcenterserviceService', () => {
  let service: DiagnosticcenterserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DiagnosticcenterserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
